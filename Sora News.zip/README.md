
  # Sora

  This is a code bundle for Sora. The original project is available at https://www.figma.com/design/5b4qcnoVDyKZxkF2c1qNSt/Sora.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  